<div class="row">
	<!-- Page Header -->
	<div class="col-lg-12">
		<h1 class="page-header">Dashboard</h1>
	</div>
	<!--End Page Header -->
</div>

<div class="row">
	<!-- Welcome -->
	<div class="col-lg-12">
		<div class="alert alert-info">
			<i class="fa fa-folder-open"></i><b>&nbsp;Hello ! </b>Welcome Back <b>Jonny Deen </b>
			<i class="fa  fa-pencil"></i><b>&nbsp;2,000 </b>Support Tickets Pending to Answere. nbsp;
		</div>
	</div>
	<!--end  Welcome -->
</div>
<div class="panel panel-primary">
	<div class="panel-heading">
		<i class="fa fa-bar-chart-o fa-fw"></i>Simple Table Example
		<div class="pull-right">
			<div class="btn-group hidden">
				<button type="button" class="btn btn-default btn-xs dropdown-toggle" data-toggle="dropdown">
					Actions
					<span class="caret"></span>
				</button>
				<ul class="dropdown-menu pull-right" role="menu">
					<li><a href="#">Action</a>
					</li>
					<li><a href="#">Another action</a>
					</li>
					<li><a href="#">Something else here</a>
					</li>
					<li class="divider"></li>
					<li><a href="#">Separated link</a>
					</li>
				</ul>
			</div>
		</div>
	</div>

	<div class="panel-body">
		<div class="row">
			<div class="col-lg-12">
				<div class="table-responsive">
					<form action="" method="">
				<div class="form-group">
					<input type="text" class="form-control" value="Name here">
				</div>
				<div class="form-group">
					<input type="text" class="form-control" value="Name here">
				</div>
				<div class="form-group">
					<input type="text" class="form-control" value="Name here">
				</div>
				<div class="form-group">
					<input type="text" class="form-control" value="Name here">
				</div>
				<div class="form-group col-md-3">
					<button type="submit" class="btn btn-lg btn-primary btn-block">Update</button>
				</div>
				<div class="form-group col-md-3">
					<button type="submit" class="btn btn-lg btn-danger btn-block">Cancel</button>
				</div>
			</form>
				</div>

			</div>

		</div>
		<!-- /.row -->
	</div>
	<!-- /.panel-body -->
</div>