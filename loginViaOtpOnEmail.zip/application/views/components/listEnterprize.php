<div class="row">
  <!-- Page Header -->
  <div class="col-lg-12">
    <h1 class="page-header">Dashboard</h1>
  </div>
  <!--End Page Header -->
</div>

<div class="row">
  <!-- Welcome -->
  <div class="col-lg-12">
    <div class="alert alert-info">
      <i class="fa fa-folder-open"></i><b>&nbsp;Hello ! </b>Welcome Back <b>Jonny Deen </b>
      <i class="fa  fa-pencil"></i><b>&nbsp;2,000 </b>Support Tickets Pending to Answere. nbsp;
    </div>
  </div>
  <!--end  Welcome -->
</div>

<div class="panel panel-primary">
	<div class="row">
		<div class="col-lg-12">
			<table class="table table-bordered table-hovered">
				<thead>
					<th>Sr.No</th>
					<th>Name</th>
					<th>Email</th>
					<th>Password</th>
					<th>Action</th>
				</thead>
				<tbody>
					<tr>
						<td>1</td>
						<td>first enterprize</td>
						<td>test@email.com</td>
						<td>123456</td>
						<td><a href="<?php echo base_url('enterprize/enterprize/1') ?>">E</a>&nbsp;<a href="javascript:void(0)">D</a></td>
					</tr>
					<tr>
						<td>2</td>
						<td>second enterprize</td>
						<td>test@email.com</td>
						<td>123456</td>
						<td><a href="<?php echo base_url('enterprize/enterprize/1') ?>">E</a>&nbsp;<a href="javascript:void(0)">D</a></td>
					</tr>
					<tr>
						<td>3</td>
						<td>third enterprize</td>
						<td>test@email.com</td>
						<td>123456</td>
						<td><a href="<?php echo base_url('enterprize/enterprize/1') ?>">E</a>&nbsp;<a href="javascript:void(0)">D</a></td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</div>
