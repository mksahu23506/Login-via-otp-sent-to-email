<!-- <div class="container"> -->

  <div class="row">
    <div class="col-md-4 col-md-offset-4 text-center logo-margin ">
      <img src="assets/img/logo.png" alt=""/>
    </div>
    <div class="col-md-4 col-md-offset-4">
      <div class="login-panel panel panel-default">                  
        <div class="panel-heading">
          <h3 class="panel-title">Please Sign In</h3>
        </div>
        <?php $this->load->view('components/trErMsg'); ?>
        <div class="panel-body">
          <form role="form" method="post" action="" id="loginForm">
            <fieldset>
              <div class="form-group" id="emailDiv">
                <input class="form-control" placeholder="Enter your registered Email to Login" name="users_email" type="email" autofocus required="" id="users_email">
              </div>
              <div class="form-group hidden" id="otpDiv">
                <input class="form-control" placeholder="Enter OTP, Sent on your email" name="users_otp" type="text" value="" required="">
              </div>
                <!-- <div class="checkbox">
                  <label>
                    <input name="remember" type="checkbox" value="Remember Me">Remember Me
                  </label>
                </div> -->
               <!--  <div class="pull-right">
                  <label>
                    <a name="forgotPassword" id="forgotPassword" href="javascript:void(0);">Forgot Password</a>
                  </label>
                </div> -->
                <!-- Change this to a button or input when using this as a form -->
                <button class="btn btn-lg btn-success btn-block" type="button" id="showOtp">Login</button>
                <button class="btn btn-lg btn-success btn-block hidden" type="submit" id="submit">Continue</button>
                <a href="<?php echo base_url('Site/register');?>" class="btn btn-lg btn-primary btn-block">Register</a>
              </fieldset>
            </form>
          </div>
        </div>
      </div>
    </div>
    <!-- </div> -->
    <script>
      $(document).ready(function(){
        $('#showOtp').on('click',function(){
          var users_email = $('#users_email').val();
          if(users_email)
          {
            $.ajax({
              url: '<?php echo base_url('Site/sendOtp');?>',
              type: 'POST',
              data: {users_email: users_email},
            })
            .done(function(result) {
              // console.log(result);
              switch(result)
              {
                case 'Invalid':
                alert('Invalid Email');
                break;
                case 'updateError':
                alert('Connection Error. Please try later');
                break;
                case 'sent':
                alert('Check your email for OTP, valid for 1 hour');
                $('#otpDiv').removeClass('hidden');
                $('#emailDiv').addClass('hidden');
                $('#showOtp').addClass('hidden');
                $('#submit').removeClass('hidden');
                break;
                default:
                alert('Something Went Wrong. Please Try AfterSomeTime');
                break;
              }
            })
            .fail(function(result) {
              console.log("error");
            });
            // .always(function(result) {
            //   console.log("complete");
            // });
            
          }
          else
          {
            alert('Please provide a valid Email');
          }
        });
        // prevent page from submit
        setTimeout(function(){
          $('form').on('keyup keypress', function(e) {
            var keyCode = e.keyCode || e.which;
            if (keyCode === 13) { 
              e.preventDefault();
              return false;
            }
          });
        },1000);
      });
    </script>