<!-- <div class="container"> -->

  <div class="row">
    <div class="col-md-4 col-md-offset-4 text-center logo-margin ">
      <img src="assets/img/logo.png" alt=""/>
    </div>
    <div class="col-md-4 col-md-offset-4">
      <div class="login-panel panel panel-default">                  
        <div class="panel-heading">
          <h3 class="panel-title">Please Register</h3>
        </div>
        <?php $this->load->view('components/trErMsg'); ?>
        <div class="panel-body">
          <form role="form" method="post" action="">
            <fieldset>

              <div class="form-group">
                <label for="users_fname" class="">First Name</label>
                <input class="form-control" placeholder="Enter First Name" name="users_fname" type="text" autofocus>
              </div>

              <div class="form-group">
                <label for="users_lname" class="">Last Name</label>
                <input class="form-control" placeholder="Enter Last Name" name="users_lname" type="text">
              </div>

              <div class="form-group">
                <label for="users_email" class="">Email</label>
                <input class="form-control" placeholder="Enter Email" name="users_email" type="email">
              </div>

              <div class="form-group">
                <label for="users_mobile" class="">Mobile</label>
                <input class="form-control" placeholder="Enter Mobile No" name="users_mobile" type="text">
              </div>

              <div class="form-group">
                <label for="users_country" class="">Country</label>
                <select name="users_country" id="users_country" class="form-control" required="">
                  <option value="">--Select Country--</option>
                  <?php foreach ($country as $countryRow) { ?>
                    <option value="<?php echo $countryRow->Country_Id;?>"><?php echo $countryRow->Country_Name;?></option>
                  <?php } ?>
                </select>
              </div>

              <div class="form-group">
                <label for="users_state" class="">State</label>
                <!-- <input class="form-control" placeholder="Enter State" name="users_state" type="text"> -->
                <select name="users_state" id="users_state" class="form-control" required="">
                  <option value="">--Select State--</option>
                </select>
              </div>

              <div class="form-group">
                <label for="users_address" class="">Address</label>
                <input class="form-control" placeholder="Enter Address" name="users_address" type="text">
              </div>

              <div class="form-group">
                <label for="users_password">Password</label>
                <input class="form-control" placeholder="Enter Password" name="users_password" type="password" value="">
              </div>
              <div class="form-group">
                <input class="form-control" placeholder="Confirm Password" name="confirm_users_password" type="password" value="">
              </div>

              <!-- Change this to a button or input when using this as a form -->
              <button class="btn btn-lg btn-success btn-block" type="submit">Register</button>
              <a href="<?php echo base_url('Site/');?>" class="btn btn-lg btn-primary btn-block">Login</a>
            </fieldset>
          </form>
        </div>
      </div>
    </div>
  </div>
  <!-- </div> -->
  <script>
    $('#users_country').on('change',function(){
      var users_country = $(this).val();
      var states = '<option value=""> -- Select State -- </option>';
      if(users_country)
      {
        $.ajax({
          url: '<?php echo base_url('Site/getStates/');?>'+users_country,
          type: 'POST',
          // data: {users_email: users_email},
        })
        .done(function(result) {
        // console.log(result);
        if(result == 'noID')
        {
          alert('No country selected');
        }
        else
        {
          // console.log($.parseJSON(result));
          result = JSON.parse(result);
          $.each(result,function(i, e) {
            // console.log(result[i]);
            states += '<option value="'+result[i].State_Id+'">'+result[i].State_Name+'</option>';
          });
          $('#users_state').html(states);
        }
      })
        .fail(function(result) {
          console.log("error");
        });
      }
      else
      {
        alert('Please select country');
      }
    });
  </script>