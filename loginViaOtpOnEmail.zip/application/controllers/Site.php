<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Site extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
	{
		parent::__construct();
		$this->load->model('commonModal');
		$this->load->library('Phpmailer');
		$this->loginUser = $this->session->userdata('loginUser')[0];
		if($this->loginUser != NULL)
		{
			redirect('Dashboard');
		}
	}

	public function index()
	{
		$RequestMethod = $this->input->server('REQUEST_METHOD');
		// if user submit the page
		if($RequestMethod == 'POST')
		{
			// send otp on email and then allow to login
			$users_email = $this->input->post('users_email');
			$users_otp   = md5($this->input->post('users_otp'));
			$result      = $this->commonModal->verify_login('users', $users_email, $users_otp);
			if($result != 'invalid')
			{				
				$this->session->set_userdata('loginUser',$result);
				// echo "<pre>"; print_r($this->session->userdata('loginUser')[0]); exit();
				redirect('Dashboard');
			}
			else
			{
				$this->session->set_flashdata('er_msg', 'Invalid Email or Password');
				redirect(current_url());
			}
		}

		$content['subview'] = 'login';
		$this->load->view('main_layout',$content);
	}

	public function register()
	{
		$RequestMethod = $this->input->server('REQUEST_METHOD');
		// if user submit the page
		if($RequestMethod == 'POST')
		{

			$users_email  = $this->input->post('users_email');
			$users_mobile = $this->input->post('users_mobile');
			$insertArray  = array(
				'users_fname'    => $this->input->post('users_fname'),
				'users_lname'    => $this->input->post('users_lname'),
				'users_email'    => $users_email,
				'users_mobile'   => $users_mobile,
				'users_country'  => $this->input->post('users_country'),
				'users_state'    => $this->input->post('users_state'),
				'users_address'  => $this->input->post('users_address'),
				'users_password' => md5($this->input->post('users_password')),
			);

			// check and validate
			if($this->input->post('confirm_users_password') != $this->input->post('users_password'))
			{
				$this->session->set_flashdata('er_msg', 'Password do not match');
				redirect(current_url());
			}
			if(empty($this->input->post('users_fname')) || empty($this->input->post('users_email')) || empty($this->input->post('users_mobile')) || empty($this->input->post('users_password')))
			{
				$this->session->set_flashdata('er_msg', 'All fields are mandatory');
				redirect(current_url());
			}
			// echo "<pre>"; print_r($insertArray); exit();
			$check = array(
				'users_email'  => $users_email,
				'users_mobile' => $users_mobile,
			);
			$result = $this->commonModal->insertRecord('users',$insertArray,$check);
			if($result == 'duplicate')
			{
				$this->session->set_flashdata('er_msg', 'Email or Mobile No already exist. Please try with different data');
				redirect(current_url());
			}
			elseif ($result == 'insert')
			{
				$this->session->set_flashdata('tr_msg', 'Registered successfully');
				redirect(current_url());
			}
			else
			{
				$this->session->set_flashdata('er_msg', 'Connection problem. Please try later');
				redirect(current_url());
			}
		}

		$country = $this->commonModal->fetchRecord('country', array('Country_Status' => 0));
		$content['country'] = $country;
		$content['subview'] = 'register';
		$this->load->view('main_layout',$content);
	}

	public function sendOtp()
	{
		// print_r($this->input->post()); exit();
		$users_email = $this->input->post('users_email');
		$where       = array(
			'users_email' => $users_email,
		);
		$result = $this->commonModal->fetchRecord('users',$where);
		if($result == 'error')
		{
			echo 'Invalid';
		}
		else
		{
			$otp         = $this->generateOtp();
			$updateArray = array(
				'users_otp'     => md5($otp),
				'users_otpDate' => date('Y-m-d H:i:s'),
			);
			// update otp to database
			$resultUpdtae = $this->commonModal->updateRecord('users',$updateArray,$where);
			if($resultUpdtae == 'updated')
			{
				// send same otp to user email to validate
				// echo json_encode($result[0]);
				$email = $this->commonModal->send_email('OTP To Login', 'Enter the below OTP to login<br>'.$otp, $result[0]->users_email, $result[0]->users_fname.' '.$result[0]->users_lname);
				if($email)
				{
					echo 'sent';
				}
				else
				{
					echo 'not sent';
				}
			}
			else
			{
				echo 'updateError';
			}
		}
	}

	private function generateOtp()
	{
		return rand(100000,9999999999);
	}

	public function getStates($countryId=NULL)
	{
		if($countryId)
		{
			$where = array(
				'State_CountryId' => $countryId,
				'State_Status'    => 0,
			);
			$result = $this->commonModal->fetchRecord('state',$where);
			echo json_encode($result);
		}
		else
		{
			echo 'noID';
		}
	}
}
