<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CommonModal extends CI_Model {

	public function verify_login($tableName=NULL,$users_email=NULL,$users_otp=NULL)
	{
		$where = array(
			'users_email' => $users_email,
			'users_otp'   => $users_otp,
		);
		$this->db->select('users_id, users_fname, users_lname, users_email, users_mobile, users_role');
		$this->db->where($where);
		$result = $this->db->get($tableName)->result();
		// die($this->db->last_query());
		if(count($result) > 0)
		{
			return $result;
		}
		else
		{
			return 'invalid';
		}
	}

	public function insertRecord($tableName=NULL,$insertArray=NULL,$check=NULL)
	{
		$this->db->or_where($check);
		$result = $this->db->get($tableName)->result();
		// echo "<pre>"; print_r($result); exit();
		if(count($result) > 0)
		{
			return 'duplicate';
		}
		else
		{
			$this->db->insert($tableName,$insertArray);
			return 'insert';
		}
	}

	public function fetchRecord($tableName=NULL,$where=NULL)
	{
		$this->db->where($where);
		$result = $this->db->get($tableName)->result();
		if(count($result) > 0)
		{
			// valid email id provided by user
			return $result;
		}
		else
		{
			return 'error';
		}
	}

	public function updateRecord($tableName=NULL,$updateArray=NULL,$where=NULL)
	{
		$this->db->where($where);
		$this->db->set($updateArray);
		$this->db->update($tableName);
		// echo $this->db->affected_rows(); exit();
		if($this->db->affected_rows())
		{
			return 'updated';
		}
		else
		{
			return 'error';
		}
	}

	public function send_email($subject, $body, $to_email, $to_name=null, $attachments=array())
	{
		//echo $to_email;die;

		// if (ENVIRONMENT == "development") {
		// 	return "SUCCESS: Message sent!";
		// }
		//die('jjjj');

		$loginDetails = $this->db->get('tblsaas_customer')->row();	
		//echo "<pre>";print_r($loginDetails);die;

		// date_default_timezone_set('Etc/UTC');
		date_default_timezone_set('Asia/Kolkata');

		//Create a new PHPMailer instance
		$mail = new Phpmailer;

		//Tell PHPMailer to use SMTP
		$mail->isSMTP();

		//Enable SMTP debugging
		// 0 = off (for production use)
		// 1 = client messages
		// 2 = client and server messages
		$mail->SMTPDebug   = 0;
		// $mail->SMTPDebug   = 3;

		//Ask for HTML-friendly debug output
		$mail->Debugoutput = 'html';

		//Set the hostname of the mail server
		$mail->Host        = $loginDetails->Smtp_Hostname;
		// use
		// $mail->Host     = gethostbyname('smtp.gmail.com');
		// if your network does not support SMTP over IPv6

		//Set the SMTP port number - 587 for authenticated TLS, a.k.a. RFC4409 SMTP submission
		$mail->Port        = $loginDetails->Smtp_Port;

		//Set the encryption system to use - ssl (deprecated) or tls
		$mail->SMTPSecure  = 'tls';

		//Whether to use SMTP authentication
		$mail->SMTPAuth    = true;

		//Username to use for SMTP authentication - use full email address for gmail
		$mail->Username    = $loginDetails->Smtp_Username;

		//Password to use for SMTP authentication
		$mail->Password    = $loginDetails->Smtp_Password;

		//Set who the message is to be sent from
		$mail->setFrom($loginDetails->Smtp_Username, $loginDetails->Org_Name);

		//Set an alternative reply-to address
		// $mail->addReplyTo('replyto@example.com', 'First Last');

		//Set who the message is to be sent to
		// $mail->addAddress('kkumar.sandeep89@gmail.com', 'test');
		$mail->addAddress($to_email, ($to_name==null?'':$to_name));

		//Set the subject line
		$mail->Subject = $loginDetails->Org_Name . ' - ' . $subject;

		//Read an HTML message body from an external file, convert referenced images to embedded,
		//convert HTML into a basic plain-text alternative body
		$mail->msgHTML($body);

		//Replace the plain text body with one created manually
		// $mail->AltBody = 'This is a plain-text message body';

		//Attach an image file
		if(count($attachments)>0){
			foreach($attachments as $attachment){
				if(file_exists(FCPATH  . 'datafiles/' . $attachment)){
					$mail->addAttachment(FCPATH  . 'datafiles/' . $attachment);
				}else{
					return "ERROR: attachment file ". FCPATH  . 'datafiles/' . $attachment . " does not exists";
				}
			}
		}
		// echo "<pre>"; print_r($mail->send()); exit();
		//send the message, check for errors
		if (!$mail->send()) {
			return "ERROR: Mailer Error: " . $mail->ErrorInfo;
		} else {
			return "sent";
		}	
	}

}

/* End of file commonModal.php */
/* Location: ./application/models/commonModal.php */